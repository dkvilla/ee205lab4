for ( IntListIterator it ( ilist . start () ) ; it != ilist . end () ; it ++)
    cout << * it << endl;