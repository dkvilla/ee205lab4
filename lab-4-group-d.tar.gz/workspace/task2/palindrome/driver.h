#include "listnode.h"
void printc(Container c, char ch);
void print(Entry x);